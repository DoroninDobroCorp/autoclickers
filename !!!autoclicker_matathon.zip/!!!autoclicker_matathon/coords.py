login_coords = (1138, 134)
                556, 356
                596, 406
                631, 492
live_coords = (491, 131)
match_input_coords = (1248, 194)
                        1036, 194
                        282, 359
PREDEFINED_OUTCOME_COORDS = {
        "1": (489, 515),
        "X": (551, 515),
        "2": (598, 515)
    }
OUTCOME_SEARCH_REGION = 
BET_INPUT_CANDIDATES = (1171, 307)
Координаты подтверждения ставки = (1219, 416)


 PREDEFINED_OUTCOME_COORDS = {
        "1": (483, 547),
        "X": (543, 547,
        "2": (606, 547)
    }